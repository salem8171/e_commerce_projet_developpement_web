
-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(100) NOT NULL,
  `product_cat` varchar(100) NOT NULL,
  `product_brand` int(100) NOT NULL,
  `product_title` varchar(255) NOT NULL,
  `product_price` int(100) NOT NULL,
  `product_desc` text NOT NULL,
  `product_image` text NOT NULL,
  `product_keywords` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_cat`, `product_brand`, `product_title`, `product_price`, `product_desc`, `product_image`, `product_keywords`) VALUES
(16, '9', 7, 'Product_1', 100, '<p>This is a clothing named Product_1 belonging to a categorie named Categorie_1, it is very appealing and good looking.</p>', 'robe courte.jpg', 'clothing'),
(17, '9', 7, 'Product_2', 200, '<p>This is a clothing named Product_2 belonging to a categorie named Categorie_1, it is very appealing and good looking.</p>', 'sweeter.jpg', 'clothing'),
(18, '9', 7, 'Product_3', 300, '<p>This is a clothing named Product_3 belonging to a categorie named Categorie_1, it is very appealing and good looking.</p>', 'sweetershirt.jpg', 'clothing'),
(19, '9', 7, 'Product_4', 400, '<p>This is a clothing named Product_4 belonging to a categorie named Categorie_1, it is very appealing and good looking.</p>', 'coat.jpg', 'clothing'),
(20, '9', 7, 'Product_5', 500, '<p>This is a clothing named Product_5 belonging to a categorie named Categorie_1, it is very appealing and good looking.</p>', 'casual dresses.jpg', 'clothing'),
(21, '10', 7, 'Product_6', 600, '<p>This is a clothing named Product_6 belonging to a categorie named Categorie_2, it is very appealing and good looking.</p>', 'Print Dresses.jpg', 'clothing'),
(22, '10', 7, 'Product_7', 700, '<p>This is a clothing named Product_7 belonging to a categorie named Categorie_2, it is very appealing and good looking.</p>', 'Long Sleeve Dresses.jpg', 'clothing'),
(23, '10', 7, 'Product_8', 800, '<p>This is a clothing named Product_8 belonging to a categorie named Categorie_2, it is very appealing and good looking.</p>', 'Pants.jpg', 'clothing'),
(24, '10', 7, 'Product_9', 900, '<p>This is a clothing named Product_9 belonging to a categorie named Categorie_2, it is very appealing and good looking.</p>', 'Skirts.jpg', 'clothing'),
(25, '10', 7, 'Product_10', 1000, '<p>This is a clothing named Product_10 belonging to a categorie named Categorie_2, it is very appealing and good looking.</p>', 'Jeans.jpg', 'clothing'),
(26, '11', 8, 'Product_11', 1100, '<p>This is a clothing named Product_11 belonging to a categorie named Categorie_3, it is very appealing and good looking.</p>', 'Shirts.jpg', 'clothing'),
(27, '11', 8, 'Product_12', 1200, '<p>This is a clothing named Product_11 belonging to a categorie named Categorie_3, it is very appealing and good looking.</p>', 'Tees & Tanks.jpg', 'clothing'),
(28, '11', 8, 'Product_13', 1300, '<p>This is a clothing named Product_13 belonging to a categorie named Categorie_3, it is very appealing and good looking.</p>', 'Jackets & Coats.jpg', 'clothing'),
(29, '11', 8, 'Product_14', 1400, '<p>This is a clothing named Product_14 belonging to a categorie named Categorie_3, it is very appealing and good looking.</p>', 'Pantsm.jpg', 'clothing'),
(30, '11', 8, 'Product_15', 1500, '<p>This is a clothing named Product_15 belonging to a categorie named Categorie_3, it is very appealing and good looking.</p>', 'Shorts.jpg', 'clothing'),
(31, '11', 8, 'Product_16', 1600, '<p>This is a clothing named Product_16 belonging to a categorie named Categorie_3, it is very appealing and good looking.</p>', 'Jeansm.jpg', 'clothing');
